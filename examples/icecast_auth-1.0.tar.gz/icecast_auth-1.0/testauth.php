<form method=POST action="action.php">
<table border=0>
<tr><td>Username</td><td><input type=text name="user" size=30></td></tr>
<tr><td>Password</td><td><input type=text name="pass" value="monkey" size=30></td></tr>
<tr><td>Mountpoint</td><td><input type=text name="mount" value="/mystream.ogg" size=30></td></tr>
<tr><td>Server</td><td><input type=text name="server" value="localhost" size=30></td></tr>
<tr><td>Port</td><td><input type=text name="port" value="8000" size=30></td></tr>
<tr><td>Action</td><td><input type=text name="action" value="auth" size=30></td></tr>

</table>
<input type="Submit">
</form>
