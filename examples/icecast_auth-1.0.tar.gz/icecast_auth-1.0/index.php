<? include "header.php"; ?>
<h2>Welcome</h2>
<div class="roundcont">
<div class="roundtop">
<img alt="" src="images/corner_topleft.jpg" class="corner" style="display: none" />
</div>
<div class="newscontent">
<h3>Welcome</h3>
<p>
You are successfully logged in.  Please use the top navigation bar to see all the features of the application.
	<br>
	<br>
	<br>
</p>
</div>
<div class="roundbottom">
<img alt="" src="images/corner_bottomleft.jpg" class="corner" style="display: none" />
</div>	
</div>
<? include "footer.php"; ?>
