<?
$adminUser = 'admin';
$adminPassword = 'hackme';

$mysql_db = 'icecast_auth';
$mysql_user = '';
$mysql_password = '';
$mysql_host = 'localhost';

$table_prefix = 'icecastauth_';
?>
